###########################################################################################################################################################
# BFS Capstone Project - Credit Scoring for CreditX
###########################################################################################################################################################
# 00-Business Understanding
# 01-Prep/Initiation
# 02-Data Prep/Understanding/EDA 
# 03-Model Buliding & Evaluation
# 04-Model Deployment & Conclusions/Reccomendation
###########################################################################################################################################################

#-----------------------------------------------------------------------------------------
# 00-Business Understanding
#-----------------------------------------------------------------------------------------
#CredX is a leading credit card provider. It has experienced an increase in credit loss in the past few years & needs to mitigate credit
#risk by 'acquiring the right customers'. We will help CredX identify the right customers using predictive model based scorecard to minimize
#credit losses.Credit application data & data from credit bureau is available for 71295 applications. Determining the the factors affecting 
#credit risk, create strategies to mitigate the acquisition risk and highlighting the financial benefit of the solution are the key objectives of this project
#-----------------------------------------------------------------------------------------
# 01-Prep/Initiation
#-----------------------------------------------------------------------------------------
#Ensure you set correct working directory using setwd
#setwd("C:/02_Personal/OneDrive/08_PGDDS/17_Capstone")

#Set working directory and install all required packages below before you run the code.
#Loading required library
library(ggplot2)
library(caTools)
library(MASS)
library(car)
library(dplyr)
library(corrplot)
library(DMwR)
library(ROCR)
library(randomForest)
library(ROSE)
library(woeBinning)
library(scorecard)
library(stringr)
library(Information)
library(caret)
library(MLmetrics)

#Functions

#Function to calculate confusion matrix for Logistic Regression & Other models with change in cutoff
calculate_confusion_matrix <- function(cutoff) 
{
  predicted_response <- factor(ifelse(test_pred >=cutoff, "Yes", "No"))
  actual_response <- factor(ifelse((test$performance==1), "Yes", "No"))
  test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
  acc <- test_conf$overall[1]
  sens <- test_conf$byClass[1]
  spec <- test_conf$byClass[2]
  out <- t(as.matrix(c(cutoff,sens, spec, acc))) 
  colnames(out) <- c("cutoff","sensitivity", "specificity", "accuracy")
  return(out)
}

#Function to calculate confusion matrix for RF models with change in cutoff
RF_confusion_matrix <- function(cutoff) 
{
  predicted_response <- as.factor(ifelse(testPred[, 2] >= cutoff, "Yes", "No"))
  actual_response <- rf_test_data$performance
  conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(cutoff,sens, spec, acc))) 
  colnames(out) <- c("cutoff","sensitivity", "specificity", "accuracy")
  return(out)
}


#Function to calculate & plot lift-gain
lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  
  #Plot gain chart
  pred <- prediction(predicted_prob, labels)
  gain <- performance(pred, "tpr", "rpp")
  
  plot(x=c(0, 1), y=c(0, 1), type="l", col="red", lwd=2,ylab="Rate of Actual Defaults", xlab="Rate of Predicted Defaults")
  title(main="Cumulative Gain Chart")
  lines(x=unlist(slot(gain, 'x.values')), y=unlist(slot(gain, 'y.values')), col="green", lwd=3)
  
  return(gaintable)
  
}

#Function to calculate KS Statistics Score,Area Under ROC Curve and GINI & Plot ROC Curve
modeltests <- function(test_cutoff_churn , test_actual_churn) {
  
#KS Test on testing  data
pred_object_test<- prediction(test_cutoff_churn, test_actual_churn)
performance_measures_test<- performance(pred_object_test, "tpr", "fpr")
ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

Area_ROCR <- performance(pred_object_test, measure = "auc")
Area_ROCR <- Area_ROCR@y.values[[1]]
Area_ROCR

pred_default <- data.frame(fpr=unlist(performance_measures_test@x.values), tpr=unlist(performance_measures_test@y.values))
gini<-(Area_ROCR*2)-1
cat("KS Statistics Score:",round(max(ks_table_test),digits = 2),"\nArea Under ROC Curve:",round(Area_ROCR,digits = 2),"\nGINI:",round(gini,digits = 2))


ggplot(pred_default ,aes(x=fpr, y=tpr)) +
  geom_line(colour="BLUE") +
  geom_line(data=data.frame(), aes(x=c(0,1), y=c(0,1)), colour="black") +
  labs(x="% False Positive", y="% True Positive",title="ROC Curve") +
  theme(axis.text.x=element_text(hjust=1))+ annotate("text", x=0.4, y=0.00, hjust=0, vjust=0, size=5,
                                                     label=paste("AUC =", round(Area_ROCR, 3))) 

}

#Function for plotting cutoff values vs confusion matrix values 
plotcutoff <- function(cutoff_range , conf_matrix_values){
plot(cutoff_range, conf_matrix_values[,2],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(cutoff_range,conf_matrix_values[,3],col="darkgreen",lwd=2)
lines(cutoff_range,conf_matrix_values[,4],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))
}

#Function to replace values in data frame with respective woe value
impute_woe_df <- function(woe_df,orig_df,bnslist,wlist) {
  for(i in 2:ncol(orig_df)){
    binlst=bnslist[[i-1]]
    woelst=wlist[[i-1]]
    colname=orig_df[,i]
    for(j in 1:length(binlst)){
      if(binlst[j]=="NA"){
        colname[which(is.na(colname))] <- woelst[j]
      } else {
        if(is.numeric(colname)==T){
          numbins<-as.integer(unlist(str_extract_all(binlst[j],"\\d+")))
          colname[which(colname %in% numbins[1]:numbins[2])] = woelst[j]
        } else {
          colname[ which(colname == binlst[j]) ] = woelst[j]
        }
        
      }
    }
    woe_df[,i]<- colname
  }
  
  return(woe_df)
}


#Function to plot default rate for each variable
plot_defaults <- function(cat_var, var_name,ds){
  aggr <- aggregate(performance~cat_var, ds, mean)
  count <- data.frame(table(cat_var))
  count <- count[,-1]
  agg_response <- cbind(aggr, count)
  
  colnames(agg_response) <- c(var_name, "performance","No.of_cust")
  agg_response[, 2] <- format(round(agg_response[, 2], 2))
  
  ggplot(agg_response, aes(agg_response[, 1], count, label = as.factor(performance))) + geom_bar(stat = 'identity') + theme(axis.text.x = element_text(angle = 60, hjust = 1)) + geom_text(size = 3, vjust = -0.5) + xlab(var_name)
}


#-----------------------------------------------------------------------------------------
# 02-Data Prep/Understanding/EDA 
#-----------------------------------------------------------------------------------------
# Load data. 
credit_bureau_data<- read.csv("Credit Bureau data.csv",stringsAsFactors = F)
demographic_data<-read.csv("Demographic data.csv",stringsAsFactors = F)

str(demographic_data) #71295 obs. of  12 variables
str(credit_bureau_data)#71295 obs. of  19 variables

names(demographic_data)[names(demographic_data) == 'Application.ID']<-"appid"
names(demographic_data)[names(demographic_data) == 'Marital.Status..at.the.time.of.application.']<-"Marital.Status"
names(demographic_data)[names(demographic_data) == 'Performance.Tag']<-"performance"
names(demographic_data)[names(demographic_data) == 'No.of.months.in.current.residence']<-"current.res.dur"
names(demographic_data)[names(demographic_data) == 'No.of.months.in.current.company']<-"current.empl.dur"
names(credit_bureau_data)<-c("appid","DPD90_6M","DPD60_6M","DPD30_6M","DPD90_12M","DPD60_12M","DPD30_12M","Avg_CCUtil","trades_6M","trades_12M","PL_trades_6M","PL_trades_12M","enq_6M","enq_12M","open_hsgloan","outst_bal","total_trades","open_autoloan","performance")

## Check duplicates
sum(duplicated(credit_bureau_data$appid)==T)
##3 application id's are duplicate
setdiff(demographic_data[duplicated(demographic_data$appid),"appid"],credit_bureau_data[duplicated(credit_bureau_data$appid),"appid"])
#both dataset have same appid duplicated

credit_bureau_data[duplicated(credit_bureau_data$appid),"appid"]
# 765011468,653287861,671989187 are duplicate ID's

#Remove duplicare records
demographic_data <- demographic_data[-which(duplicated(demographic_data$appid) == T), ]
credit_bureau_data <- credit_bureau_data[-which(duplicated(credit_bureau_data$appid) == T), ]
nrow(credit_bureau_data)#71292

merged_df<- merge(x = unique(demographic_data), y = unique(credit_bureau_data), by = c("appid", "performance"))

str(merged_df)#71292 obs. of  29 variables
#We'll not need appid hence can be removed
merged_df$appid<-NULL


length(which(is.na(merged_df$performance)==T))*100/nrow(merged_df)
#About 2% records have performance=NA which are the applications rejected.We'll save these for later analysis.
rejected_applications<-merged_df[which( is.na(merged_df$performance)),]

length(which(merged_df$performance=='1'))*100/nrow(merged_df)
#4.13% subjects in the data have defaulted.
#It was observed that unbalanced data does not give balanced models.
#We'll balance this data using ROSE/SMOTE afer treatment

#Save a copy of original data before further cleanup
merged_df_original<-merged_df

#data excluding rejected applicants
merged_df<-merged_df[which(is.na(merged_df$performance)==0),]  

sapply(merged_df, function(x) sum(is.na(x)))
# performance               Age            Gender    Marital.Status  No.of.dependents            Income         Education        Profession 
#           0                 0                 0                 0                 3                 0                 0                 0 
# Type.of.residence   current.res.dur  current.empl.dur          DPD90_6M          DPD60_6M          DPD30_6M         DPD90_12M         DPD60_12M 
#                 0                 0                 0                 0                 0                 0                 0                 0 
# DPD30_12M        Avg_CCUtil         trades_6M        trades_12M      PL_trades_6M     PL_trades_12M            enq_6M           enq_12M 
#         0              1023                 1                 0                 0                 0                 0                 0 
# open_hsgloan         outst_bal      total_trades     open_autoloan 
#          272               272                 0                 0 


#It is observed that some char variables do contain empty values-We'll need to treat these
sapply(merged_df, function(x) length(which(x=="")))
#Gender-2
#Marital.Status-6
#Education-118
#Profession-13
#Type.of.residence-8

str(merged_df)
#We will remove all small number of NA & empty records.since number of records containing NA/space
#is very small compared to size of the total data.Avg_CCUtil, Education & open_hsgloan will be substituted
#with woe values later on since they have both defaults & non defaults.

merged_df<-merged_df[which(is.na(merged_df$outst_bal)==0),]  
merged_df<-merged_df[which(is.na(merged_df$No.of.dependents)==0),]  
merged_df<-merged_df[which(is.na(merged_df$trades_6M)==0),]  

#Gender,Marital.Status,Type.of.residence and Profession contains blank values which need to be removed
merged_df<-merged_df[-which(merged_df$Gender==""),]  
merged_df<-merged_df[-which(merged_df$Marital.Status==""),]  
merged_df<-merged_df[-which(merged_df$Type.of.residence==""),] 
merged_df<-merged_df[-which(merged_df$Profession==""),]  

sapply(merged_df, function(x) sum(is.na(x))) #Now only Avg CC Utilization has 750 NA values-which will be replaced by WoE values.

str(merged_df)#69563 obs. of  28 variables
summary(merged_df)
#Income and Age have invalid(-ve) values/outliers which need to be treated as part of outlier treatment.
#Outstanding Balance seems to have very wide range-We'll check & treat outliers.

sapply(rejected_applications, function(x) sum(is.na(x)))
# performance               Age            Gender    Marital.Status  No.of.dependents            Income         Education        Profession 
#        1425                 0                 0                 0                 0                 0                 0                 0 
# Type.of.residence   current.res.dur  current.empl.dur          DPD90_6M          DPD60_6M          DPD30_6M         DPD90_12M         DPD60_12M 
#                 0                 0                 0                 0                 0                 0                 0                 0 
# DPD30_12M        Avg_CCUtil         trades_6M        trades_12M      PL_trades_6M     PL_trades_12M            enq_6M           enq_12M 
#         0                35                 0                 0                 0                 0                 0                 0 
# open_hsgloan         outst_bal      total_trades     open_autoloan 
#            0                 0                 0                 0 


sapply(rejected_applications, function(x) length(which(x=="")))
#Education  1
#Profession 1

#As observed above, there are some values with profession and education as "".We'll remove such values
rejected_applications <- rejected_applications[-which(rejected_applications$Profession==""),]
rejected_applications <- rejected_applications[-which(rejected_applications$Education==""),]
sapply(rejected_applications, function(x) sum(is.na(x)))#1423 records
str(rejected_applications)#1423 obs. of  28 variables

#################################################EDA#####################################################################
#We'll perform Univariate & Mutivariate analysis and treat outliers-if any
#Note -As per fair lending practices,discriminatory variables will not be part of our final model.

#Age-----
summary(merged_df$Age)
#45 is mean age and 45 is meadian and mean is close to median.
quantile(merged_df$Age,seq(0,1,0.01))
#0th quantile is -3 -which is invalid and 27 is age for first quantile.Last quantiles are 65-looks reasonable.
#We'll assume that to get credit card, you'll need to be legal adult.
#and remove data for individuals who have reported age below 18
length(which(merged_df$Age<18))
#62 records have age less than 18-small number

merged_df<-merged_df[which(merged_df$Age > 17),]  

nrow(merged_df)#69501

mean(merged_df$Age)#Mean age is not changed 

ggplot(merged_df,aes(x=Age,fill=as.factor(performance)))+geom_histogram(stat="count")+ 
  scale_x_discrete(name ="Age", 
                   limits=seq(10,70,3))
#From 27-56 number of defaults seem to be higher 

table(merged_df[which(merged_df$performance==1),"Age"])
# 20  23  24  25  26  27  28  29  30  31  32  33  34  35  36  37  38  39  40  41  42  43  44  45  46  47  48  49  50  51  52  53  54  55  56  57 
# 2   1   3   2   1  60  54  59  57  61  68  44  58  71 100  95 115 109 106 105  97 105  79  90  98  99 102  99  80  88  89  75  82  87 110  54 
# 58  59  60  61  62  63  64  65 
# 38  46  46  36  43  37  47  35
#36-56 age range shows higher defaults and highest number of defaults at 38
plot_defaults(merged_df$Age,"Age",merged_df)
#36-56 shows almost same rate of default.High numbers of applicants are cause of more default numbers
#This variable has low IV value and is of very low importance

##Gender----------------------------------------------------------------
summary(as.factor(merged_df$Gender))
# F     M 
# 16424 53077 
table(merged_df[which(merged_df$performance==1),"Gender"])
# F    M 
# 717 2221 
#More male applicants as well as defaults.

ggplot(merged_df,aes(x=Gender,fill=as.factor(performance)))+geom_bar(stat="count") 
#males count wise are highest proportion
ggplot(merged_df,aes(x=Gender,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
# male and female have same ratio of default
plot_defaults(merged_df$Gender,"Gender",merged_df)
#Same rate of defaults for male-female-Gender is not important variable from IV analysis as well as fair lending practice

#No.of.dependents------------------------------------
unique(merged_df$No.of.dependents)
#[1] 5 4 1 2 3
summary(merged_df$No.of.dependents)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1.00    2.00    3.00    2.86    4.00    5.00

ggplot(merged_df,aes(x=No.of.dependents,fill=as.factor(performance)))+geom_bar(stat="count") 
#subjects with 1&3 dependents have slightly higher defaults-more applicants
#4,5 have less defaults
ggplot(merged_df,aes(x=No.of.dependents,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 

plot_defaults(merged_df$No.of.dependents,"No.of.dependents",merged_df)
#Same rate of defaults for all levels
table(merged_df[which(merged_df$performance==1),"No.of.dependents"])
# 1   2   3   4   5 
# 667 586 694 491 500
#Higher number of defaults for those with 3 and 1 dependant although overall difference is very small in all categories.

##Income------------------------------------
summary(merged_df$Income)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -0.50   14.00   27.00   27.4   40.00   60.00
#Income contains negative values
quantile(merged_df$Income,seq(0,1,0.01))
#0th quantile contains invalid values.1st to 6th % contains 4.5 overall distribution looks good.
#We'll impute invalid values with 4.5
merged_df$Income[which(merged_df$Income < 4.5)] <-4.5

ggplot(merged_df,aes(x=Income,fill=as.factor(performance)))+geom_histogram(stat="count")+ 
  scale_x_discrete(name ="Income", 
                   limits=seq(-10,60,5))
#Low income group - 4.5LPA seems to have highest applicants as well as highest defaults

ggplot(merged_df,aes(x=Income,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
#ratio is fluctuating but in the same range, this variable might have some importance
table(merged_df[which(merged_df$performance==1),"Income"])
#At income of 4.5LPA, there're highest number of defaults

plot_defaults(merged_df$Income,"Income",merged_df)
#Lower income group shows highest default rate and numbers.Also the data shows that largest number of applicants have reported 
#4.5LPA as their income.This needs to be checked for correctness and if found true, CreditX may want to see why so many low income
#subjects are applying credit with it.
# Income seems to be a weak predictor hence it may or may not appear in our final model

#Education--------------------------------------------------------------------
summary(as.factor(merged_df$Education))
#Professional has higest applicants 24259 

ggplot(merged_df,aes(x=Education,fill=as.factor(performance)))+geom_bar(stat="count") 
#High number of defaults in Maters and professional category

table(merged_df[which(merged_df$performance==1),"Education"])
#Highest defaults in Professional & Master category

ggplot(merged_df,aes(x=Education,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
#Education-others catagory seems to be defaulting more in ratio but number of defaults is less

plot_defaults(as.factor(merged_df$Education),"Education",merged_df)
#Other's have highest default rate and rest other have same default rate although number of defaults in professional 
#and master catagory is high as seen in above table
#This may not be an important variable.

###Profession---------------------------------------------
summary(as.factor(merged_df$Profession))
# SAL      SE     SE_PROF 
# 39468   13869   16164 

ggplot(merged_df,aes(x=Profession,fill=as.factor(performance)))+geom_bar(stat="count") 
#Salaried subjects have high requests as well as defaults

ggplot(merged_df,aes(x=Profession,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
#Self Employed seems to have slightly higher defailt ratio

table(merged_df[which(merged_df$performance==1),"Profession"])
# SAL      SE   SE_PROF 
# 1626     637     675

plot_defaults(merged_df$Profession,"Profession",merged_df)
#Self Employed have slightly higher default rate although salaried have highest number of request as well as defaults.
#May not be imp variable.

##Type.of.residence-------------- 
summary(as.factor(merged_df$Type.of.residence))
# Company provided Living with Parents    Others            Owned              Rented 
# 1593                1755                 198               13933              52022 

ggplot(merged_df,aes(x=Type.of.residence,fill=as.factor(performance)))+geom_bar(stat="count") 
#rented followed by owned covers maximum number of the defaults

ggplot(merged_df,aes(x=Type.of.residence,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
#slightly higher default ratio in company provided category or living with parents

table(merged_df[which(merged_df$performance==1),"Type.of.residence"])
# Company provided Living with Parents              Others         Owned              Rented 
#               73            80                   5                 588                2192 

plot_defaults(merged_df$Type.of.residence,"Type.of.residence",merged_df)
#Default rate is almost similar in all categories-slightly higher in company provided category or living with parents
#May not be important variable


##No.of.months.in.current.residence------------
summary(merged_df$current.res.dur)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 6.00    6.00   10.00   34.67   61.00  126.00 

quantile(merged_df$current.res.dur,seq(0,1,0.01))
#47% of subjects have stayed in current residence for 6 months 

ggplot(merged_df,aes(x=current.res.dur,fill=as.factor(performance)))+geom_histogram(stat="count")+ 
  scale_x_discrete(name ="Current Residence Duration", 
                   limits=seq(1,130,5))
#only spike at 6, seems as noted earlier-due to 47% of applicants 
ggplot(merged_df,aes(x=current.res.dur,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
# fluctuating default ratio across values

plot_defaults(merged_df$current.res.dur,"current.res.dur",merged_df)
table(merged_df[which(merged_df$performance==1),"current.res.dur"])
#Although 6 months show highest defaults(1032), number of subjects reported is also very high
#Hence this variable may not be a good predictor.We will leave this data as it is.

##current.empl.dur---------------------
summary(merged_df$current.empl.dur)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 3.0    17.0    34.0    34.21    51.0   133.0 

ggplot(merged_df,aes(x=current.empl.dur,fill=as.factor(performance)))+geom_histogram(stat="count")+ 
  scale_x_discrete(name ="current.empl.dur", 
                   limits=seq(0,135,5))
#Applications as well as Defaults seems high for lower number of months.CreditX needs to check why there are more number
#of applicants who've just joined organization.

ggplot(merged_df,aes(x=current.empl.dur,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') + 
  scale_x_discrete(name ="current.empl.dur", 
                   limits=seq(0,135,5))
#variying ratio,however very low number of months show higher defaults.
table(merged_df[which(merged_df$performance==1),"current.empl.dur"])
#Same inference as seen from plot is reflected by the default numbers
#People who have lowest duration in current employment are showing highest defaults.
plot_defaults(merged_df$current.empl.dur,"current.empl.dur",merged_df)

##Marital.Status----------------
summary(as.factor(merged_df$Marital.Status))
# Married  Single 
# 59251   10250
#Majority of data contains married subjects

ggplot(merged_df,aes(x=Marital.Status,fill=as.factor(performance)))+geom_bar(stat="count") 
#Married subjects have high defaults as well.

table(merged_df[which(merged_df$performance==0),"Marital.Status"])
#Higher number of defaults in case of married people
# Married  Single 
# 56755    9808 

ggplot(merged_df,aes(x=Marital.Status,fill=as.factor(performance)))+geom_bar(stat="count",position = 'fill') 
#ratio is  same , may be it will not be an important factor

plot_defaults(merged_df$Marital.Status,"Marital.Status",merged_df)
#Same rate of defaults in both categories

########################################################################
#Credit Bureau data
########################################################################

#We have merged the credit beauro data already in merged_df.We will use this df to do EDA on CB variables
colnames(credit_bureau_data)
# [1] "appid"         "DPD90_6M"      "DPD60_6M"      "DPD30_6M"      "DPD90_12M"     "DPD60_12M"     "DPD30_12M"     "Avg_CCUtil"   
# [9] "trades_6M"     "trades_12M"    "PL_trades_6M"  "PL_trades_12M" "enq_6M"        "enq_12M"       "open_hsgloan"  "outst_bal"    
# [17] "total_trades"  "open_autoloan" "performance"  
# Checking remaining missing values


#DPD90_6M---
quantile(merged_df$DPD90_6M,seq(0,1,0.01))
#78% of subjects are not 90DPD in past 6M which can help narrow our focus on 90DPDs 
table(merged_df[which(merged_df$performance==1),"DPD90_6M"])
#High number of people-970 who are 90 DPD once in past 6 month have defaulted.
#Also there are 1785 subjects who were not 90DPD in 6M however have defaulted.
plot_defaults(merged_df$DPD90_6M,"DPD90_6M",merged_df)
#Higher the number of DPDs more the default ratio - higher defaults at 3 times DPD followed by 2
#This is one of the important variables for the model to watch for
sum(merged_df[which(merged_df$DPD90_6M>0), c("performance")])*100/length(merged_df[which(merged_df$DPD90_6M>0), c("performance")])
#7.59
sum(merged_df[which(merged_df$DPD90_6M<=0), c("performance")])*100/length(merged_df[which(merged_df$DPD90_6M<=0), c("performance")])
#3.29%
#7.59 % default rate for those who are 90DPD for 1 or more time. 3.29% default  rate in those who have not been 90DPD in 6M

#DPD60_6M---
quantile(merged_df$DPD60_6M,seq(0,1,0.01))
# 74% of subjects are not 60DPD in past 6M which can help narrow our focus
table(merged_df[which(merged_df$performance==1),"DPD60_6M"])
# 0    1    2    3    4    5 
# 1573  783  389  148   39    6 
#High number of people who are 1 or 2 times 60DPD have defaulted alongwith those who have never been 60DPD

plot_defaults(merged_df$DPD60_6M,"DPD60_6M",merged_df)
#Higher the number of DPDs more the default ratio.This is also an important variable
sum(merged_df[which(merged_df$DPD60_6M>0), c("performance")])*100/length(merged_df[which(merged_df$DPD60_6M>0), c("performance")])
sum(merged_df[which(merged_df$DPD60_6M<=0), c("performance")])*100/length(merged_df[which(merged_df$DPD60_6M<=0), c("performance")])

#7.6 % default rate for those who are 60DPD for 1 or more time. 3.05% default  rate in those who have not been 60DPD in 6M


#DPD30_6M---
quantile(merged_df$DPD30_6M,seq(0,1,0.01))
#71% of subjects are not 30DPD in past 6M which can help narrow our focus
table(merged_df[which(merged_df$performance==1),"DPD30_6M"])
#   0    1    2    3    4    5     6    7 
# 1446  622  466  245  107   43    8    1 
#High number of people who are 1 or 2 times 30DPD have defaulted alongwith those who have never been 30DPD
#This is consistent with other trends - CreditX should focus on this parameter overall to catch probability of default.

plot_defaults(merged_df$DPD30_6M,"DPD30_6M",merged_df)
#Higher DPDs seem to show more defaults - higher default rate at 5 times DPD followed by 4
#This is an important variable
sum(merged_df[which(merged_df$DPD30_6M>0), c("performance")])*100/length(merged_df[which(merged_df$DPD30_6M>0), c("performance")])
#7.56 % default rate for those who are 30DPD for 1 or more time. 2.91% default  rate in those who have not been 30DPD in 6M


#DPD90_12M---
quantile(merged_df$DPD90_12M,seq(0,1,0.01))
#72% of subjects are not 90DPD in past 12M which can help narrow our focus
table(merged_df[which(merged_df$performance==1),"DPD90_12M"])
# 0      1    2    3    4    5 
# 1501  796  488  120   28    5 
#Poeple who have been 90DPD in 12M 1-3 times show high defaults alongwith those who have never been 90DPD

plot_defaults(merged_df$DPD90_12M,"DPD90_12M",merged_df)
#Higher times 90DPDs seem to show more default ratio
#This is an important variable.

sum(merged_df[which(merged_df$DPD90_12M>0), c("performance")])*100/length(merged_df[which(merged_df$DPD90_12M>0), c("performance")])
sum(merged_df[which(merged_df$DPD90_12M<=0), c("performance")])*100/length(merged_df[which(merged_df$DPD90_12M<=0), c("performance")])
#7.43 % default rate for those who are 90DPD for 1 or more time. 3% default  rate in those who have not been 90DPD in 12M

#DPD60_12M----
quantile(merged_df$DPD60_12M,seq(0,1,0.01))
#Nearly 65% of subjects are not 60DPD in past 12M which can help narrow our focus
table(merged_df[which(merged_df$performance==1),"DPD60_12M"])
# 0    1    2    3    4    5    6 
# 1369  663  482  274  101   36   13 
#People who have been 60DPD 1-4 times seem to have more no of defaults apart from high number of people who
#never defaulted.

plot_defaults(merged_df$DPD60_12M,"DPD60_12M",merged_df)
#Higher 60DPDs in 12M seem to show more default rate
sum(merged_df[which(merged_df$DPD60_12M>0), c("performance")])*100/length(merged_df[which(merged_df$DPD60_12M>0), c("performance")])
#6.55 % default rate for those who are 60DPD for 1 or more time. 3% default  rate in those who have not been 60DPD in 12M

#DPD30_12M---------
quantile(merged_df$DPD30_12M,seq(0,1,0.01))
#Nearly 64% of subjects are not 30DPD in past 12M which can help narrow our focus
table(merged_df[which(merged_df$performance==1),"DPD30_12M"])
# 0    1    2    3    4    5    6    7    8 
# 1307  518  451  349  173   89   38   11    2 
#Subjects who have been 30DPD 1 or 2 times in past 12 M show high numbers alongwith those who never have been
plot_defaults(merged_df$DPD30_12M,"DPD30_12M",merged_df)
#Higher 30DPD in 12M seem to show more defaults
#This is an important variable

sum(merged_df[which(merged_df$DPD30_12M>0), c("performance")])*100/length(merged_df[which(merged_df$DPD30_12M>0), c("performance")])
sum(merged_df[which(merged_df$DPD30_12M<=0), c("performance")])*100/length(merged_df[which(merged_df$DPD30_12M<=0), c("performance")])
#6.53 % default rate for those who are 60DPD for 1 or more time. 2.94% default  rate in those who have not been 60DPD in 12M

boxplot(merged_df$Avg_CCUtil)
#Box plot shows outliers who are at 113% - which could be genuine overuse cases


#In general it can be concluded that DPD is a good indicator to probed as a variable in our model since it shows
#ability to descriminate between defaulters and those who will not default.
#Although large number of subjects who never were DPD  but defaulted, overall default rate of such non DPD population is very low.

##Avg CC Utilization##-------------------------------------------------------
summary(merged_df$Avg_CCUtil)
#75% people have used uoto 45% of their cc limit.

quantile(merged_df$Avg_CCUtil,seq(0,1,0.01),na.rm = T)
#79% of subjects have used nearly 50% of their credit card limit
#Last 5 percent show usage more than 100%

length(merged_df[which(merged_df$Avg_CCUtil>=100), c("Avg_CCUtil")])
#3663 have fully used/exceeded their credit limit-and are 100% or above this is more than 5% of the data
#We will assume that  some financial institution may have overdraft/and the 100% limit may be soft limit
#We'll leave this data as it is since it is reported by credit agencies.


table(merged_df[which(merged_df$performance==1),"Avg_CCUtil"])
#High number of people(151) who have used 113% of their limit have defaulted.


ggplot(merged_df,aes(x=Avg_CCUtil,fill=as.factor(performance)))+
  geom_histogram(position = 'dodge',bins =  10) 
#Higher CC % seems higher default rates

plot_defaults(merged_df$Avg_CCUtil,"CCutil",merged_df)
#Plot shows high number of people who are using more than 100% of their limit and are defaulting at 
#higher rate

sum(merged_df[which(merged_df$Avg_CCUtil>25), c("performance")])*100/length(merged_df[which(merged_df$Avg_CCUtil>25), c("performance")])
sum(merged_df[which(merged_df$Avg_CCUtil<=25), c("performance")])*100/length(merged_df[which(merged_df$Avg_CCUtil<=25), c("performance")])
#6.87 - High defalt rate in people who have used more than 25% of their credit limit compared to 2.63% for upto 25%



#This is an important predictor.


#trades_6M---
table(merged_df[which(merged_df$performance==1),"trades_6M"])
#  0   1   2   3   4   5   6   7   8   9  10  11 
# 264 533 638 599 436 212 109  65  52  21   7   2 
#High number of people who have 1-4 trades have defaulted.

quantile(merged_df$trades_6M,seq(0,1,0.01),na.rm = T)
#Only 17% population does not have any trades in 6M
#24% population has 4 or higher trades
plot_defaults(merged_df$trades_6M,"trades_6M",merged_df)
#people with 3-5 trades have higher default rate.


sum(merged_df[which(merged_df$trades_6M>=2), c("performance")])*100/length(merged_df[which(merged_df$trades_6M>=2), c("performance")])
sum(merged_df[which(merged_df$trades_6M<2), c("performance")])*100/length(merged_df[which(merged_df$trades_6M<2), c("performance")])
#5.7% default rate for 2 or more trades.While those below 2 were found to default only 2.5
#This is an important variable

#trades_12M---
table(merged_df[which(merged_df$performance==1),"trades_12M"])
# 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25 
# 103 177 178 198 208 232 267 268 305 214 199 136 115  74  50  40  46  28  26  26  19  15   3   5   5   1 
#Number of defaults seem to gradually grow and peak at 8 trades and then taper down
quantile(merged_df$trades_12M,seq(0,1,0.01))
#6% population does not have any trades in 12M
plot_defaults(merged_df$trades_12M,"trades_12M",merged_df)
#Same trend is reflected by default rates

sum(merged_df[which(merged_df$trades_12M>=4), c("performance")])*100/length(merged_df[which(merged_df$trades_12M>=4), c("performance")])
sum(merged_df[which(merged_df$trades_12M<4), c("performance")])*100/length(merged_df[which(merged_df$trades_12M<4), c("performance")])
sum(merged_df[which(merged_df$trades_12M==8), c("performance")])*100/length(merged_df[which(merged_df$trades_12M==8), c("performance")])

#High default rate of 5.78 for those who have 4 or more trades in a year  vs those who have less than 4 trades at 2.19
#8% default rate for people with 8 trades.
#This is an important predictor

#PL_trades_6M
table(merged_df[which(merged_df$performance==1),"PL_trades_6M"])
# 0   1   2   3   4   5   6 
# 690 691 803 501 197  48   8
#High number of defaults at 1-4 PL trades in 6M
quantile(merged_df$PL_trades_6M,seq(0,1,0.01))
#44% subjects do not have even 1 PL trade in past 6M
plot_defaults(merged_df$PL_trades_6M,"PL_trades_6M",merged_df)
#people with 1-4 trades have higher default rate(34% of population)

sum(merged_df[which(merged_df$PL_trades_6M>=1), c("performance")])*100/length(merged_df[which(merged_df$PL_trades_6M>=1), c("performance")])
sum(merged_df[which(merged_df$PL_trades_6M==0), c("performance")])*100/length(merged_df[which(merged_df$PL_trades_6M==0), c("performance")])
#5.8% default rate in population with 1 or more pl trade in 6M. vs 2.24 in those with no PL trade
#This also seems important predictor

#PL_trades_12M
table(merged_df[which(merged_df$performance==1),"PL_trades_12M"])
# 0   1   2   3   4   5   6   7   8   9  10  11  12 
# 448 247 366 507 535 391 243 109  50  28  10   3   1 
#High number of defaults at 1-6 PL trades in 12M

quantile(merged_df$PL_trades_12M,seq(0,1,0.01))
#36% subjects do not have single PL trade in past 12 M
plot_defaults(merged_df$PL_trades_12M,"PL_trades_12M",merged_df)
#People with 3-6 trades have high rate of defaults
sum(merged_df[which(merged_df$PL_trades_12M>=1), c("performance")])*100/length(merged_df[which(merged_df$PL_trades_12M>=1), c("performance")])
sum(merged_df[which(merged_df$PL_trades_12M==0), c("performance")])*100/length(merged_df[which(merged_df$PL_trades_12M==0), c("performance")])
#High default rate of 5.66 for people with one or more PL Trade in past 12M vs 1.76 in those with no PL Trade in 12 M


#enq_6M---
table(merged_df[which(merged_df$performance==1),"enq_6M"])
# 0   1   2   3   4   5   6   7   8   9  10 
# 520 657 664 517 269 150  73  40  33  13   2 
#People with 1-3 enquiries in past 6M have higher defaults

quantile(merged_df$enq_6M,seq(0,1,0.01))
#35% did not have any enq. in past 6M
plot_defaults(merged_df$enq_6M,"enq_6M",merged_df)
#1-5 enquiries in 6M has more defaults

sum(merged_df[which(merged_df$enq_6M>=1), c("performance")])*100/length(merged_df[which(merged_df$enq_6M>=1), c("performance")])
sum(merged_df[which(merged_df$enq_6M==0), c("performance")])*100/length(merged_df[which(merged_df$enq_6M==0), c("performance")])
#5.4% default rate when there is 1 or more enq in past 6M VS 2.1% with no enq.

#enq_12M---
table(merged_df[which(merged_df$performance==1),"enq_12M"])
# 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17 
# 306 149 380 443 380 362 247 209 141  71  84  53  40  26  23  12   6   6 
#2-5 enquiries in past 12M show higher number of defaults

quantile(merged_df$enq_12M,seq(0,1,0.01))
#29% population did not have any enq in past 12M
plot_defaults(merged_df$enq_12M,"enq_12M",merged_df)
#2-8 &10 enquiries in 6M has more default ratio

sum(merged_df[which(merged_df$enq_12M>=1), c("performance")])*100/length(merged_df[which(merged_df$enq_12M>=1), c("performance")])
sum(merged_df[which(merged_df$enq_12M==0), c("performance")])*100/length(merged_df[which(merged_df$enq_12M==0), c("performance")])
#5.37% default rate when there is 1 or more enq in past 12M VS 1.49% with no enq.

#open_hsgloan---

table(merged_df[which(merged_df$performance==1),"open_hsgloan"])
# 0    1 
# 2332  606 
#606 Subjects who have open hsg loan defaulted
quantile(merged_df$open_hsgloan,seq(0,1,0.01),na.rm = T)
#74% of people do not have open hsg loan.

plot_defaults(merged_df$open_hsgloan,"open_hsgloan",merged_df)
#People that do not have housing loan seem to have more default rate
#Housing loan may not be a good indicator of default compared to other variables

sum(merged_df[which(merged_df$open_hsgloan==1), c("performance")])*100/length(merged_df[which(merged_df$open_hsgloan==1), c("performance")])
sum(merged_df[which(merged_df$open_hsgloan==0), c("performance")])*100/length(merged_df[which(merged_df$open_hsgloan==0), c("performance")])

#default rate in subjects who have housing loan is 3.37 vs it is 4.53 for those who do not have housing loan

#outst_bal---------

summary(merged_df$outst_bal)
#Range is from 0 to 5218801
boxplot(merged_df$outst_bal) 
#There're outlier values
quantile(merged_df$outst_bal, seq(0,1,0.01),na.rm = T)
#Sudden jump of 10lakh in 100th percentile.We'll impute 100th percentile values with 99th percentile
merged_df$outst_bal[which(merged_df$outst_bal >4250993)] <- 4250993
histogram(merged_df$outst_bal,breaks=c(-Inf,100000,500000,750000,1000000,1500000,3000000,4300000,Inf))
boxplot(merged_df$outst_bal)#Seems better

sum(merged_df[which(merged_df$outst_bal>=500000), c("performance")])*100/length(merged_df[which(merged_df$outst_bal>=500000), c("performance")])
sum(merged_df[which(merged_df$outst_bal<500000), c("performance")])*100/length(merged_df[which(merged_df$outst_bal<500000), c("performance")])
#4.94% for outstanding balance above 5L vs 2.98% below balance of 5L.

#total_trades---
table(merged_df[which(merged_df$performance==1),"total_trades"])
# 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25  26  27  28  29  30  31  32  33 
# 34  44 105 184 205 230 237 270 296 282 221 163 142  89  55  27  18  10  15  17  24  21  25  29  31  25  30  26  19  17  10  12  10   9 
# 34  35  36  39 
# 3   1   1   1 
#Large number of defaults at total trades between 4-10

quantile(merged_df$total_trades,seq(0,1,0.01))
#Only 1% population does not have trades
#50% population is between 4-10 trades
plot_defaults(merged_df$total_trades,"total_trades",merged_df)
#6-15 range of trades shows higher defaults

sum(merged_df[which(merged_df$total_trades>6), c("performance")])*100/length(merged_df[which(merged_df$total_trades>6), c("performance")])  
#5.87 default rate for subjects with 7 trades or above.It is observed that default rate increased beyond 5% above 4 trades or more

#open_autoloan---
table(merged_df[which(merged_df$performance==1),"open_autoloan"])
# 0    1 
# 2719  219 
#Small number of people with auto loan have defaulted
#May not be significant

quantile(merged_df$open_autoloan,seq(0,1,0.01))
#91% people do not have auto loan
plot_defaults(merged_df$open_autoloan,"open_autoloan",merged_df)
#Equal default in both categories- not significant variable.



#We created some derived variables and tested our model however at the end, it did not make any major impact so we did not use these.
# merged_df$income_age<-merged_df$Income/merged_df$Age
# merged_df$income_dependent<-merged_df$Income/merged_df$No.of.dependents 
# merged_df$resi_age<-merged_df$current.res.dur/merged_df$Age
# merged_df$comp_age<-merged_df$current.empl.dur/merged_df$Age
# merged_df$resi_income<-merged_df$current.res.dur/merged_df$Income
# merged_df$comp_income<-merged_df$current.empl.dur/merged_df$Income
# 
# merged_df$income_age<-merged_df$Income/merged_df$Age
# merged_df$income_dependent<-merged_df$Income/merged_df$No.of.dependents 
# merged_df$resi_age<-merged_df$current.res.dur/merged_df$Age
# merged_df$comp_age<-merged_df$current.empl.dur/merged_df$Age
# merged_df$resi_income<-merged_df$current.res.dur/merged_df$Income
# merged_df$comp_income<-merged_df$current.empl.dur/merged_df$Income
# merged_df$age_DPD90_6M<-merged_df$Age/ifelse(merged_df$DPD90_6M==0,1,merged_df$DPD90_6M)
# merged_df$age_PL_trades_6M<-merged_df$Age/ifelse(merged_df$PL_trades_6M==0,1,merged_df$PL_trades_6M)
# merged_df$Income_DPD90_6M<-merged_df$Income/ifelse(merged_df$DPD90_6M==0,1,merged_df$DPD90_6M)
# merged_df$Income_enq_6M<-merged_df$Income/ifelse(merged_df$enq_6M==0,1,merged_df$enq_6M)
# merged_df$current.res.dur_DPD60_12M<-merged_df$current.res.dur/ifelse(merged_df$DPD60_12M==0,1,merged_df$DPD60_12M)
# merged_df$current.empl.dur_DPD60_12M<-merged_df$current.empl.dur/ifelse(merged_df$DPD60_12M==0,1,merged_df$DPD60_12M)
# merged_df$current.res.dur_DPD30_6M<-merged_df$current.res.dur/ifelse(merged_df$DPD30_6M==0,1,merged_df$DPD30_6M)
# merged_df$current.res.dur_trades_12M<-merged_df$current.res.dur/ifelse(merged_df$trades_12M==0,1,merged_df$trades_12M)
# names(merged_df)
# merged_df$outst_bal.empl.dur<-merged_df$outst_bal_bin_WOE/ifelse(merged_df$current.empl.dur==0,1,merged_df$current.empl.dur)
# merged_df$Avg_CCUtil_current.res.dur<-merged_df$Avg_CCUtil/ifelse(merged_df$current.res.dur==0,1,merged_df$current.res.dur)

#Data prep for logistic regression
#We'll WoE values using optimized binning provided by woebin method
#for logistic regression where NA values in Avg CC Utilization  will be taken care of
woebins <- woebin(merged_df, "performance")
lr_woe_merged_data <- woebin_ply(merged_df, woebins)
#Invert performnce tag since we want to predict approvals via the automated model.
lr_woe_merged_data$performance<-ifelse(lr_woe_merged_data$performance==1,0,1)

#############################Corelation########################################
#Check correlation of performance with numeric variables
merged_df_numeric<-na.omit(merged_df[sapply(merged_df, is.numeric)])
cortable<-cor(merged_df_numeric)
View(cortable)
corrplot(cortable, method="circle")

#performance variable seems to have good correlation with Credit beauro data variables.
#It's seen that correlation plot is able to show correlation with important variables identified in EDA
#It is also observed that strong correlationship exists amongst DPD columns - which indicates that people may have tendancy to  
#be repete DPD in payments

##############################################################################
# Information value and WOE calculation
# The information package is used for woe calculation. 
# One slight change you need to perform before applying the "create_infotable"
# This package indicates "1" as a good customer but in our dataset, we have assigned "1" bad customers
# Thus we have to change the label to get the correct value of woe value. 

nondefault_merged_df <- merged_df
# Rechange the levels to "1" for good customer and "0" for bad customers
nondefault_merged_df$performance <- ifelse(nondefault_merged_df$performance==1,0,1)


#We'll create data frame based on this data with only important variables using WoE/IV Analysis.

Infoval <- create_infotables(nondefault_merged_df,y="performance")
#Infoval$Tables contains tables of woe values and Infoval$Summary contains IV summary

Infoval$Summary
# 0.3 to 0.5	Strong predictor
# 0.1 to 0.3	Medium predictor
# 0.02 to 0.1	Weak predictor

str(Infoval$Tables) #List of data frames which contain bins as 1st variable  and WoE as 4th variable

#We'll create new data frames and replace actual values with woe values
#Perform replacements with WoE-merged df_all columns
binslist<-lapply(Infoval$Tables,`[[`, 1)
woelist<-lapply(Infoval$Tables,`[[`, 4)
woe_df<-merged_df
merged_woe_df<-impute_woe_df(woe_df,merged_df,binslist,woelist)
merged_woe_df$performance <- as.factor(merged_woe_df$performance)


Infoval$Summary[which(Infoval$Summary$IV>0.1),]
# Variable        IV
# 1     Avg_CCUtil 0.3118158
# 2     trades_12M 0.2992422
# 3  PL_trades_12M 0.2976330
# 4        enq_12M 0.2965392
# 5      outst_bal 0.2469674
# 6       DPD30_6M 0.2420549
# 7   total_trades 0.2378859
# 8   PL_trades_6M 0.2203559
# 9      DPD90_12M 0.2142245
# 10      DPD60_6M 0.2062044
# 11        enq_6M 0.2052807
# 12     DPD30_12M 0.1987550
# 13     trades_6M 0.1864486
# 14     DPD60_12M 0.1858931
# 15      DPD90_6M 0.1603274

#These are the strong and medium predictor variables
# 0.3 to 0.5	Strong predictor
plot_infotables(Infoval, "Avg_CCUtil")#WoE is -ve for Avg CC Util beyond 22% 
plot_infotables(Infoval, "trades_12M")#WoE is -ve for 4 or more trades in 12M
plot_infotables(Infoval, "PL_trades_12M")#WoE is -ve for 2 or more PL Trades in 12M
plot_infotables(Infoval, "enq_12M")#WoE is -ve for 2 or more enquiries in 12M

# 0.1 to 0.3	Medium predictor
plot_infotables(Infoval, "outst_bal")#WoE is -ve for outstanding balances above 3.86 Lakh
plot_infotables(Infoval, "DPD30_6M")#WoE is -ve for 1 or more 30DPD  in 6 Months
plot_infotables(Infoval, "total_trades")#WoE is -ve for total trades above 5
plot_infotables(Infoval, "PL_trades_6M")#WoE is -ve for PL Trades above 1 in 6M
plot_infotables(Infoval, "DPD90_12M")#WoE is -ve for 1 or more 90DPD in 12M
plot_infotables(Infoval, "DPD60_6M")#WoE is -ve for 1 or more 60DPD in 12M
plot_infotables(Infoval, "enq_6M")#WoE is -ve for 1 or more enquiries in 6M
plot_infotables(Infoval, "DPD30_12M")#WoE is -ve for 1 or more 30DPD in 12M
plot_infotables(Infoval, "trades_6M")#WoE is -ve for 2 or more trades in 6M
plot_infotables(Infoval, "DPD60_12M")#WoE is -ve for 1 or more 60DPD in 12M
plot_infotables(Infoval, "DPD90_6M")#WoE is -ve for 1 or more 90DPD in 6M

# 0.02 to 0.1	Weak predictor
plot_infotables(Infoval, "current.res.dur")#WoE is -ve for 10 or more current res dur
plot_infotables(Infoval, "Income")#WoE is -ve for Income below 31
plot_infotables(Infoval, "current.empl.dur")#WoE is -ve for current.empl.dur below 27 and also for 34-40,62-133

#We do not get monotonic trends for all variables
#Based on Univariate/Multivariate analysis and IV/WoE analysis, we can pick only strong and medium variables for building models.
#We'll use only Strong & Medium variables in model building process 
impvars<-Infoval$Summary$Variable[which(Infoval$Summary$IV>0.1)]
head(Infoval$Summary)
#Avg_CCUtil, trades_12M,PL_trades_12M,enq_12M,outst_bal,DPD30_6M are the top 6 important variables and should be part of our model unless there's multicollinearity.

str(Infoval$Tables) #List of data frames which contain bins as 1st variable  and WoE as 4th variable


#-------We'll create new data frames and replace actual values with woe values

#We'll create WoE DF with only select columns for model building
select_woe_df<-merged_woe_df[, c("performance",impvars)]

#Perform replacements with WoE-rejected records-rejected applications
woe_df<-rejected_applications
reject_woe_df<-impute_woe_df(woe_df,rejected_applications,binslist,woelist)
reject_woe_df<-reject_woe_df[, c("performance",impvars)]


#Balance train data using SMOTE since there are less defaults compared to total data.
set.seed(9000)
indices <- sample.split(select_woe_df$performance, SplitRatio = 0.70)
train <- select_woe_df[indices, ]
test <- select_woe_df[!indices, ]
#Balance using SMOTE-After multiple iterations of SMOTE,perc.over = 100, perc.under=200 was found to balance data 
train_smote <- SMOTE(performance ~ ., train, perc.over = 100, perc.under=200)
summary(train_smote$performance)
# 0    1 
# 4114 4114 
#Data is balanced

#Data for RF
set.seed(1100)
select_woe_df$performance <- as.factor(ifelse(select_woe_df$performance==1,"Yes","No"))
split_indices <- sample.split(select_woe_df$performance, SplitRatio = 0.70)
rf_train_data <- select_woe_df[split_indices, ]
rf_test_data <- select_woe_df[!split_indices, ]
levels(rf_test_data$performance)
table(rf_test_data$performance)

#-----------------------------------------------------------------------------------------
# 03-Model Building & Evaluation
#-----------------------------------------------------------------------------------------

########################################################################
# Build Logistic Regression model on demographic data
########################################################################
woe_demographic_data<-lr_woe_merged_data[,1:11]

# splitting the data between train and test
set.seed(100)

indices = sample.split(woe_demographic_data$performance, SplitRatio = 0.7)

train_sample = woe_demographic_data[indices,]

test = woe_demographic_data[!(indices),]

table(train_sample$performance)
# 0     1 
# 2057 46594
#The data is not balanced-There are less defaulters compared to size of data hence we'll balance the data.

train <- ROSE(performance ~ ., data = train_sample, seed = 100)$data

table(train$performance)
# 0     1 
# 24137 24514

model_1 = glm(performance ~ ., data = train, family = "binomial")
summary(model_1) 
#AIC: 65911

# Stepwise selection
model_2<- stepAIC(model_1, direction="both")
summary(model_2) #AIC: 65911
# Call:
# glm(formula = performance ~ Age_woe + Gender_woe + No.of.dependents_woe + 
#       Income_woe + Profession_woe + Type.of.residence_woe + current.res.dur_woe + 
#       current.empl.dur_woe, family = "binomial", data = train)

sort(car::vif(model_2),decreasing = TRUE)
#All vif values are low.So we will select vars only based on importance.
#Gender_woe can be removed.
model_3<- glm(formula = performance ~ Age_woe + No.of.dependents_woe + 
                Income_woe + Profession_woe +  current.res.dur_woe + 
                current.empl.dur_woe, family = "binomial", data = train)


summary(model_3) # AIC: 65918
#All variables are important.

final_model<-model_3

########################################################################
# Model Evaluation
########################################################################
test_pred = predict(final_model, type = "response", newdata = test[,-1])
predicted_response <- factor(ifelse(test_pred >=0.5, "Yes", "No"))
actual_response <- factor(ifelse((test$performance==1), "Yes", "No"))
test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
test_conf
# Accuracy : 0.6194  
# Sensitivity : 0.62362        
# Specificity : 0.52440
#Weak model with  just demographic data

#---------------------------------------------------------    
# Let's find out the optimal probalility cutoff 
#---------------------------------------------------------    

# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 1000 X 4.
cutoff_range = seq(.01,.99,length=1000)
conf_matrix_values = matrix(0,1000,4)

for(i in 1:1000)
{
  conf_matrix_values[i,] = calculate_confusion_matrix(cutoff_range[i])
} 
conf_matrix_values[conf_matrix_values[,2]>0.57 & conf_matrix_values[,3]>0.57 & conf_matrix_values[,4]>0.57,]
#0.5112813 0.5731384 0.5732123 0.5731415
#Cutoff of 0.5112813 gives 57% Sensitivity, Specificity & Accuracy
#---------------------------------------------------------    
# plot of cutoff values vs confusion matrix values 
plotcutoff(cutoff_range,conf_matrix_values)
########################################################################
predicted_response <- factor(ifelse(test_pred >=0.5112813, "Yes", "No"))
actual_response <- factor(ifelse((test$performance==1), "Yes", "No"))
test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
test_conf
# Accuracy : 0.5731
# Sensitivity : 0.57314         
# Specificity : 0.57321
#Model built only on demographic data gives less than 60% acc,spec,sens. We will use merged data and see if it yields better results. 

########################################################################
# Build Logistic Regression model-Merged data
########################################################################

# splitting the data between train and test
set.seed(100)


indices = sample.split(lr_woe_merged_data$performance, SplitRatio = 0.7)

train_sample = lr_woe_merged_data[indices,]

test = lr_woe_merged_data[!(indices),]

#We'll use balancing here as well
train <- ROSE(performance ~ ., data = train_sample, seed = 100)$data

table(train$performance)
#Data is balanced

model_1 = glm(performance ~ ., data = train, family = "binomial")
summary(model_1) 
#AIC: 63034


# Stepwise selection
model_2<- stepAIC(model_1, direction="both")
summary(model_2) #AIC: 63029
# Call:
# glm(formula = performance ~ Age_woe + Gender_woe + No.of.dependents_woe + 
#       Income_woe + Education_woe + Profession_woe + current.res.dur_woe + 
#       current.empl.dur_woe + DPD90_6M_woe + DPD60_6M_woe + DPD30_6M_woe + 
#       DPD90_12M_woe + DPD60_12M_woe + DPD30_12M_woe + Avg_CCUtil_woe + 
#       trades_6M_woe + trades_12M_woe + PL_trades_12M_woe + enq_6M_woe + 
#       enq_12M_woe + outst_bal_woe + total_trades_woe, family = "binomial", 
#     data = train)
sort(car::vif(model_2),decreasing = TRUE)#VIF looks ok.We'll use variable importance for variable elimination.
#Based on IV,WoE analysis, in the merged data, credit beauro data variables were important.
#We'll remove demographic data variables and other CB variables that are showing less significance.
#total_trades_woe,DPD90_6M_woe


model_3<-glm(formula = performance ~ Age_woe + Gender_woe + No.of.dependents_woe + 
               Income_woe + Education_woe + Profession_woe + current.res.dur_woe + 
               current.empl.dur_woe  + DPD60_6M_woe + DPD30_6M_woe + 
               DPD90_12M_woe + DPD60_12M_woe + DPD30_12M_woe + Avg_CCUtil_woe + 
               trades_6M_woe + trades_12M_woe + PL_trades_12M_woe + enq_6M_woe + 
               enq_12M_woe + outst_bal_woe , family = "binomial", 
             data = train)



summary(model_3) # AIC: 63030

#We can reduce further variables based on IV/WoE analysis/p value.
#Income_woe + Education_woe + current.res.dur_woe can be removed
model_4<- glm(formula = performance ~ Age_woe + Gender_woe + No.of.dependents_woe + 
                 Profession_woe  + 
                current.empl.dur_woe  + DPD60_6M_woe + DPD30_6M_woe + 
                DPD90_12M_woe + DPD60_12M_woe + DPD30_12M_woe + Avg_CCUtil_woe + 
                trades_6M_woe + trades_12M_woe + PL_trades_12M_woe + enq_6M_woe + 
                enq_12M_woe + outst_bal_woe , family = "binomial", 
              data = train)

summary(model_4) # AIC: 63043

#Gender_woe + No.of.dependents_woe + trades_6M_woe  are comparitively less significant
model_5<- glm(formula = performance ~ Age_woe + 
                Profession_woe  + 
                current.empl.dur_woe  + DPD60_6M_woe + DPD30_6M_woe + 
                DPD90_12M_woe + DPD60_12M_woe + DPD30_12M_woe + Avg_CCUtil_woe + 
                trades_12M_woe + PL_trades_12M_woe + enq_6M_woe + 
                enq_12M_woe + outst_bal_woe , family = "binomial", 
              data = train)

summary(model_5) # AIC: 63064

#Age_woe + Profession_woe  + DPD60_12M_woe are comparitively less significant
model_6<- glm(formula = performance ~ 
                current.empl.dur_woe  + DPD60_6M_woe + DPD30_6M_woe + 
                DPD90_12M_woe  + DPD30_12M_woe + Avg_CCUtil_woe + 
                trades_12M_woe + PL_trades_12M_woe + enq_6M_woe + 
                enq_12M_woe + outst_bal_woe , family = "binomial", 
              data = train)

summary(model_6) # AIC: 63101

#We'll remove current.empl.dur_woe,DPD60_6M_woe,DPD30_6M_woe,DPD30_12M_woe, enq_6M_woe

model_7<- glm(formula = performance ~   DPD30_6M_woe + DPD90_12M_woe +
                Avg_CCUtil_woe + 
                trades_12M_woe + PL_trades_12M_woe +  
                enq_12M_woe + outst_bal_woe , family = "binomial", 
              data = train)

summary(model_7) # AIC: 63245

##All variables in the above model were identified as strong/medium variables in IV/WoE analysis and correlation.
#Lets take this model as final LR model for now.
final_model<-model_7
########################################################################
#Model Eval
########################################################################
test_pred = predict(final_model, type = "response", newdata = test[,-1])
predicted_response <- factor(ifelse(test_pred >=0.5, "Yes", "No"))
actual_response <- factor(ifelse((test$performance==1), "Yes", "No"))
test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
test_conf
#Accuracy :  0.565  
# Sensitivity : 0.55887        
# Specificity : 0.70488

#Improvement over just demographic data
#---------------------------------------------------------    
# Let's find out the optimal probalility cutoff 
#---------------------------------------------------------    

# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 1000 X 4.
cutoff_range = seq(.01,.99,length=1000)
conf_matrix_values = matrix(0,1000,4)

for(i in 1:1000)
{
  conf_matrix_values[i,] = calculate_confusion_matrix(cutoff_range[i])
} 
conf_matrix_values[conf_matrix_values[,2]>0.62 & conf_matrix_values[,3]>0.62 & conf_matrix_values[,4]>0.62,]
#0.4759660 0.6239171 0.6356413 0.6244125
#Cutoff of 0.4759660 gives Sensitivity  0.6239171 Specificity 0.6356413 Accuracy 0.6244125
#---------------------------------------------------------    
#Plot cutoff
plotcutoff(cutoff_range , conf_matrix_values)
########################################################################
predicted_response <- factor(ifelse(test_pred >=0.4759660, "Yes", "No"))
actual_response <- factor(ifelse((test$performance==1), "Yes", "No"))
test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
test_conf
# Accuracy : 0.6244  
# Sensitivity : 0.62392        
# Specificity : 0.63564

test_cutoff_churn <- ifelse(predicted_response=="Yes",1,0)
test_actual_churn <- ifelse(actual_response=="Yes",1,0)
modeltests(test_cutoff_churn , test_actual_churn)
# KS Statistics Score: 0.26 
# Area Under ROC Curve: 0.63 
# GINI: 0.26
#These are ok but not very good test results

# Lift & Gain Chart 
#For Cumulative gain plot, we will check model's ability to predict defaults.
test_pred = predict(final_model, type = "response", newdata = test[,-1])
predicted_response <- factor(ifelse(test_pred >=0.4759660, 1, 0))
tp<-ifelse(test$performance==1,0,1)
pp<-ifelse(predicted_response==1,0,1)
Churn_decile = lift(tp, pp, groups = 10)
Churn_decile 

#bucket total totalresp Cumresp  Gain Cumlift
#      1  2085      140.    140.  15.9    1.59
#Low cumulativelift in 1st decile
#Overall KS Statistics Score,AROC,GINI are ok but can be improved.

########################################################################
#Model Building-Random Forest
########################################################################
#Random forest model on SMOTE Data 
str(train_smote)
table(train_smote$performance)

rf_model <- randomForest( performance~., data = train_smote, proximity = F, do.trace = T, mtry = 5,ntree=500)
rf_model$importance 
#List of important variables is in line with IV/WoE analysis

rf_model
rf_model$confusion[,'class.error']
# 0         1 
# 0.2046670 0.3432183

testPred <- predict(rf_model, newdata=rf_test_data)
testPred<- as.factor(ifelse(testPred==1,"Yes","No"))
table(testPred, rf_test_data$performance)
# testPred    No   Yes
# No  16053   253
# Yes  3916   628

caret::confusionMatrix(testPred, rf_test_data$performance)
# Accuracy :  0.8
# Sensitivity : 0.8039          
# Specificity : 0.7128       

########################################################################
#Model Eval
########################################################################

testPred <- predict(rf_model, newdata=rf_test_data[,-1],type = "prob")
levels(rf_test_data$performance)
actual_response <- rf_test_data$performance
predicted_response <- as.factor(ifelse(testPred[, 2] >= 0.5, "Yes", "No"))
test_conf <- caret::confusionMatrix(predicted_response, rf_test_data$performance, positive = "Yes")
test_conf
# Accuracy : 0.7982 
# Sensitivity : 0.71283
# Specificity : 0.80199

#---------------------------------------------------------    
# Let's find out the optimal probalility cutoff 
#---------------------------------------------------------    
# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 100 X 4.
cutoff_range = seq(.01,.99,length=100)
conf_matrix_values = matrix(0,100,4)

for(i in 1:100)
{
  conf_matrix_values[i,] = RF_confusion_matrix(cutoff_range[i])
} 

conf_matrix_values[conf_matrix_values[,2]>0.72 & conf_matrix_values[,3]>0.72 & conf_matrix_values[,4]>0.72,]
#0.4554545 0.7514188 0.7470579 0.7472422
rf_cut_off<-0.4554545

# plot cutoff values vs confusion matrix values 
plotcutoff(cutoff_range , conf_matrix_values)
############################################################################
predicted_response <- as.factor(ifelse(testPred[, 2] >= rf_cut_off, "Yes", "No"))
actual_response <- rf_test_data$performance
test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response, positive = "Yes")
test_conf
# Accuracy : 0.7472
# Sensitivity : 0.75142
# Specificity : 0.74706

#F1 Score
round(F1_Score(rf_test_data$performance, predicted_response),digits = 2)
#0.85 - good F1 score

test_cutoff_churn <- ifelse(predicted_response=="Yes",1,0)
test_actual_churn <- ifelse(actual_response=="Yes",1,0)
modeltests(test_cutoff_churn , test_actual_churn)
# KS Statistics Score: 0.5 
# Area Under ROC Curve: 0.75 
# GINI: 0.5
#Imrpovement is visible in all tests
# Lift & Gain Chart 
actual_response <- factor(ifelse((rf_test_data$performance=="Yes"), 1, 0))
Churn_decile = lift(actual_response, testPred[, 2], groups = 10)
Churn_decile
#Model shows 90% gain in 6th decile.

#We can choose this as probability cutoff for our scorecard building process.
probability_cut_off<-round(rf_cut_off,digits = 2)

########################################################################
#Model Building - GBM
########################################################################
lr_woe_merged_data$performance<-ifelse(lr_woe_merged_data$performance==1,"Yes","No")
lr_woe_merged_data$performance<-as.factor(lr_woe_merged_data$performance)

set.seed(1200)
indices = sample.split(lr_woe_merged_data$performance, SplitRatio = 0.7)

traingbm = lr_woe_merged_data[indices,]

testgbm = lr_woe_merged_data[!(indices),]

#We'll use balancing here as well
train_rose <- ROSE(performance ~ ., data = traingbm, seed = 100)$data
table(train_rose$performance)
#Data is balanced

#We'll try Generalized Boosted Regression
fitControl <- trainControl(method = "repeatedcv", number = 4, repeats = 4)
library(doParallel)
cl <- makePSOCKcluster(detectCores()-1)
registerDoParallel(cl)

gbmFit1 <- train(performance ~   DPD30_6M_woe + DPD90_12M_woe +
                   Avg_CCUtil_woe + 
                   trades_12M_woe + PL_trades_12M_woe +  
                   enq_12M_woe + outst_bal_woe , data = train_rose, method = "gbm", 
                 trControl = fitControl,verbose = FALSE)
summary(gbmFit1)
# var   rel.inf
# enq_12M_woe             enq_12M_woe 35.059819
# DPD30_6M_woe           DPD30_6M_woe 18.849537
# DPD90_12M_woe         DPD90_12M_woe 12.882794
# PL_trades_12M_woe PL_trades_12M_woe 10.814473
# trades_12M_woe       trades_12M_woe 10.457336
# Avg_CCUtil_woe       Avg_CCUtil_woe  9.063231
# outst_bal_woe         outst_bal_woe  2.872810

stopCluster(cl)
########################################################################
#Model Eval
########################################################################
final_model<-gbmFit1
test_pred = predict(final_model, type = "prob", newdata = testgbm[,-1])
predicted_response <- factor(ifelse(test_pred[,2] >=0.45, "Yes", "No"))
actual_response <- testgbm$performance
test_conf <- caret::confusionMatrix(data=predicted_response, reference=actual_response)
test_conf
#GBM based is giving low acc,sens,spec

########################################################################
#Model Building - SVM
########################################################################
ncol(train_smote)#16

#Lets start with model building exercise with these set of variable
#install.packages("kernlab")
library(kernlab)
#--------------Using Linear Kernel
Model_linear <- ksvm(performance~ ., data = train_smote, scale = TRUE, kernel = "vanilladot")
Eval_linear<- predict(Model_linear, rf_test_data)
Eval_linear<- as.factor(ifelse(Eval_linear==1,"Yes","No"))
#confusion matrix - Linear Kernel
#install.packages("purrr")
library(purrr)
library(caret)
Linear.confMat<-confusionMatrix(Eval_linear,rf_test_data$performance)
Linear.confMat
# Accuracy : 0.523 
# Sensitivity : 0.51219         
# Specificity : 0.76731  
# 
#--------------Using RBF Kernel
#RBF kernal take steh logest time and is not select as teh final model 
#so feel free to ignore this section whiel evaluation
Model_RBF <- ksvm(performance~ ., data = train_smote, scale = TRUE, kernel =rbfdot(sigma = 1))
Eval_RBF<- predict(Model_RBF, rf_test_data)
Eval_RBF<- as.factor(ifelse(Eval_RBF==1,"Yes","No"))
RBF.confMat<-confusionMatrix(Eval_RBF,rf_test_data$performance)
RBF.confMat
# Accuracy : 0.649  
# Sensitivity : 0.64540         
# Specificity : 0.73099 

Model_RBF <- ksvm(performance~ ., data = train_smote, scale = TRUE, kernel =rbfdot(sigma = 50))
Eval_RBF<- predict(Model_RBF, rf_test_data)
Eval_RBF<- as.factor(ifelse(Eval_RBF==1,"Yes","No"))
RBF.confMat<-confusionMatrix(Eval_RBF,rf_test_data$performance)
RBF.confMat
# Accuracy : 0.5043 
# Sensitivity : 0.48986         
# Specificity : 0.83201 

#--------------Using Polynomial kernal, degree 2 is being used to compare as 1 would make it linear
Model_POLY <- ksvm(performance~ ., data = train_smote, scale = TRUE, kernel =polydot(degree = 2, scale = 1, offset = 1))
Eval_POLY<- predict(Model_POLY, rf_test_data)
Eval_POLY<- as.factor(ifelse(Eval_POLY==1,"Yes","No"))
POLY.confMat<-confusionMatrix(Eval_POLY,rf_test_data$performance)
POLY.confMat
#for degree 2
# Accuracy : 0.5736   
# Sensitivity : 0.56633         
# Specificity : 0.73780 

Model_POLY <- ksvm(performance~ ., data = train_smote, scale = TRUE, kernel =polydot(degree = 3, scale = 1, offset = 1))
Eval_POLY<- predict(Model_POLY, rf_test_data)
Eval_POLY<- as.factor(ifelse(Eval_POLY==1,"Yes","No"))
POLY.confMat<-confusionMatrix(Eval_POLY,rf_test_data$performance)
POLY.confMat
# Accuracy : 0.6334  
# Sensitivity : 0.63193       
# Specificity : 0.66742  

#3rd degree polynomial svm model is complex compared to RF both in terms of model complexity as well as
#from ability to explain to business as well hence we'll not persue it further
#Overall, RF model seems to be the better model of all.
#We will choose RF model as our final model for further analysis

########################################################################################################################################
##Additional models that were tried using grid however not deemed useful.Commented due to time reqd. to execute/env limitations.
########################################################################################################################################
# ##Trying out anothe ensableming algorith Gradient boosting
# y=train_smote$performance
# summary(y)
# x=train_smote[,c('Avg_CCUtil','trades_12M','PL_trades_12M','enq_12M','outst_bal','DPD30_6M',
#                  'DPD90_12M','DPD60_6M','total_trades','PL_trades_6M','DPD30_12M','trades_6M','DPD60_12M','DPD90_6M')]
# fitControl <- trainControl(method = "repeatedcv", number = 4, repeats = 4)
# # grid <- expand.grid(
# #   n.trees = seq(10, 1000, by = 100)
# #   , interaction.depth = c(4)
# #   , shrinkage = c(0.01, 0.1)
# #   , n.minobsinnode = c(5, 10, 20, 30)
# # )
# #our best set post teh grid run was
# ## n.trees interaction.depth shrinkage n.minobsinnode
# #  810                 4       0.1              5
# grid <- expand.grid(
#   n.trees = 810
#   , interaction.depth = c(4)
#   , shrinkage = c(0.1)
#   , n.minobsinnode = c( 5)
# )
# gbmFit1 <- caret::train(y=y, x=x,method = "gbm",trControl = fitControl,verbose = F, tuneGrid = grid)
# summary(gbmFit1)
# # var    rel.inf
# # Avg_CCUtil       Avg_CCUtil 25.6807578
# # outst_bal         outst_bal 15.2987792
# # enq_12M             enq_12M 14.2720617
# # PL_trades_12M PL_trades_12M 10.8636922
# # total_trades   total_trades  9.1608256
# # trades_12M       trades_12M  6.3203152
# # trades_6M         trades_6M  5.9698253
# # PL_trades_6M   PL_trades_6M  4.6019832
# # DPD90_12M         DPD90_12M  3.0055437
# # DPD60_12M         DPD60_12M  1.4335329
# # DPD30_12M         DPD30_12M  1.4137873
# # DPD30_6M           DPD30_6M  1.2149847
# # DPD90_6M           DPD90_6M  0.5651543
# # DPD60_6M           DPD60_6M  0.1987567
# testPred <- predict(gbmFit1, rf_test_data,type= "prob")[,2]
# levels(rf_test_data$performance)
# actual_response <- rf_test_data$performance
# predicted_response <- as.factor(ifelse(testPred >= 0.5, "Yes", "No"))
# test_conf <- caret::confusionMatrix(predicted_response, rf_test_data$performance, positive = "Yes")
# test_conf
# # Accuracy : 0.5309 
# # Sensitivity : 0.71964         
# # Specificity : 0.52261  
# 
# for(i in 1:100){
#   conf_matrix_values[i,] = calculate_confusion_matrix(cutoff_range[i])
# } 
# 
# 
# conf_matrix_values[conf_matrix_values[,2]>0.6 & conf_matrix_values[,3]>0.6 & conf_matrix_values[,4]>0.6,]
# #[1] 0.4752525 0.6449997 0.6152100 0.6437410
# #not at par with RF model
# testPred <- predict(gbmFit1, rf_test_data,type= "prob")[,2]
# levels(rf_test_data$performance)
# actual_response <- rf_test_data$performance
# predicted_response_GB <- as.factor(ifelse(testPred >=  0.47525253, "Yes", "No"))
# ##################################################################
# #Ensemble
# #let's see if the ensemble of the three model does better then RF one
# 
# ##ensemble
# combined_data<-as.data.frame(cbind(logi=predicted_response_LR,gbm=predicted_response_GB,rf=predicted_response_rf))
# combined_data
# t1<-apply(combined_data, 1, function(idx) which.max(tabulate(idx)))
# t1
# test_pred_churn <- factor(ifelse(t1 == 2, "Yes", "No"))
# test_actual_churn <- factor(ifelse((test$performance==1), "Yes", "No"))
# test_conf <- caret::confusionMatrix(data=test_pred_churn, reference=rf_test_data$performance, positive = "Yes")
# test_conf
# # Accuracy : 0.5915
# # Sensitivity : 0.78434         
# # Specificity : 0.58300 
# ##Our RF performce is better than enseble still!
# 
#-----------------------------------------------------------------------------------------
# 04-Model Deployment & Conclusions
#-----------------------------------------------------------------------------------------

#########################################################################################################################################
#Scorecard building
#########################################################################################################################################
#We will choose RF model as our final model
#Calculate scores based on the model for the entire data

scorecard_df<-select_woe_df
scorecard_pred<- predict(rf_model,newdata= scorecard_df[,-1], type = "prob")
scorecard_df$prob_nondefault<-scorecard_pred[,1]
scorecard_df$prob_default<-scorecard_pred[,2]

summary(scorecard_df$prob_nondefault)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.0100  0.5220  0.7100  0.6965  0.9140  1.0000

summary(scorecard_df$prob_default)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.0000  0.0860  0.2900  0.3035  0.4780  0.9900

quantile(scorecard_df$prob_default,seq(0,1,0.01))
#There are be some cases which model is marking as certain for default and certain for non default.
#For cases, where model is certain that the individual will not default, the odds will be 0 and logodds will be Inf.
table(scorecard_df$prob_nondefault[which(scorecard_df$prob_default==0)])
# 1 
# 1964 

table(scorecard_df$performance[which(scorecard_df$prob_default==0)])
# No  Yes 
# 1953   11 
11*100/1964
#Default rate is 0.56% in top scoring applications 
#1953 customers of 1964  are customers who have not defaulted.Model is clarly able to identify them with good accuracy
#Note that all these 11 customers were approved by CreditX as well and have defaulted-defaults are part of normal business scenario.
#Hence we will mark their probability of being default as lowest at 0.01 so as to not lose them from overall model business analysis.
scorecard_df$prob_default[which(scorecard_df$prob_default==0)]<-0.01

#Calculate Log Odds
scorecard_df$logodds <-  log(scorecard_df$prob_nondefault/scorecard_df$prob_default)

Offset = 400
PDO = 20
log_odds=10
Factor = PDO/log(2)
Factor  #28.8539

summary(scorecard_df$logodds)
# Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
# -4.59512  0.06402  0.83779  1.28656  2.17520  6.21261

scorecard_df$Score = round(Offset + (Factor*scorecard_df$logodds))

str(scorecard_df$Score)
summary(scorecard_df$Score)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 267.0   403.0   426.0   439.8   468.0   579.0 

quantile(scorecard_df$Score,seq(0,1,0.01))


unique(scorecard_df$Score[which(scorecard_df$prob_default==probability_cut_off)])
cutoff_score <-405

table(scorecard_df[which(scorecard_df$performance=="Yes"),"Score"])

apprrecs<-length(scorecard_df[which(scorecard_df$Score>=cutoff_score),"Score"])
apprrecs
#50656 subjects are approved by model.CreditX will get re-validation on their approvals based on important variables.

cutoffrecs<-length(scorecard_df[which(scorecard_df$Score<cutoff_score),"Score"])
cutoffrecs
#18845 subjects will be rejected by model.CreditX may want to reassess their creditworthiness before approvals. 

round((cutoffrecs*100)/nrow(scorecard_df))
#27% of total records are below cutoff

quantile(scorecard_df$Score[which(scorecard_df$performance=="Yes")],seq(0,1,0.01))
#With score of 405, we can eliminate about 72% of defaulters in 27% of overall applications.


total_no_of_defaults<-length(which(scorecard_df$performance=="Yes"))
total_no_of_defaults
#2938-total number of defaults

num_of_defaults_below_cutoff<-length(which(scorecard_df$Score<cutoff_score & scorecard_df$performance=="Yes"))
num_of_defaults_below_cutoff
#2124 total number of defaults below cutoff

perc_of_defaults_below_cutoff<-round((num_of_defaults_below_cutoff/total_no_of_defaults)*100)
perc_of_defaults_below_cutoff
#72% of total defaults

num_of_defaults_above_cutoff<-total_no_of_defaults-num_of_defaults_below_cutoff
num_of_defaults_above_cutoff
#814 of total defaults are above cutoff

perc_of_defaults_above_cutoff<-round((num_of_defaults_above_cutoff*100/total_no_of_defaults))
perc_of_defaults_above_cutoff
#28% of total defaults are above cutoff

scorecard_df$performance=ifelse(scorecard_df$performance=="Yes",1,0)
ggplot(scorecard_df, aes(x = Score,fill=as.factor(scorecard_df$performance)))+  geom_bar()+ 
  scale_fill_manual("legend", values = c("0" = "#99CC66", "1" = "black")) +
  geom_vline(aes(xintercept = cutoff_score),colour = "red")+labs(x="Score",y="Count",title="Score Distribution for all applicants")+
  annotate("text", x=370,y=450, colour = "navy",hjust=0.5, vjust=-10, size=7, label=paste("Defaults covered by cut off :" ,
           num_of_defaults_below_cutoff,"defaulters /",perc_of_defaults_below_cutoff,"% of total defaulters"))
#scale_fill_hue(c=45, l=80) + c("0" = "#99FFFF", "1" = "#3399FF")

#Score predictions for rejected applications------------------------------------------------
reject_woe_df$performance<-NULL
reject_pred<- predict(rf_model,newdata= reject_woe_df, type = "prob")

reject_woe_df$prob_nondefault<-reject_pred[,1]
reject_woe_df$prob_default<-reject_pred[,2]

summary(reject_woe_df$prob_default)
summary(reject_woe_df$prob_nondefault)

reject_woe_df$logodds <-  log(reject_woe_df$prob_nondefault/reject_woe_df$prob_default)
summary(reject_woe_df$logodds)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# -4.2546 -0.5236 -0.1201 -0.1399  0.3064  2.4698 

reject_woe_df$Score = round(Offset + (Factor*reject_woe_df$logodds))

summary(reject_woe_df$Score)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 277     385     397     396     409     471 

#This clearly shows majority of rejected population has lower scores compared to approved population.

quantile(reject_woe_df$Score,seq(0,1,0.01))


perc_of_rejects_basedon_cutoff<-round(length(which(reject_woe_df$Score<cutoff_score))*100/nrow(reject_woe_df),digits = 2)
perc_of_rejects_basedon_cutoff
# With our choosen cutoff we would have rejected 67.32% of applicants that were rejected w/o model.
# Conversly, with the model, we would be able to propose more scrutiny of these cases which otherwise would have been rejected
# Thus improving revenue.

scorecard_based_rejections=(length(which(reject_woe_df$Score < cutoff_score)))
scorecard_based_rejections
#958 subjects from rejections were confirmed by model as well aiding CreditX in rejection of likely defaulters.

scorecard_based_approvals=(length(which(reject_woe_df$Score >= cutoff_score)))
scorecard_based_approvals
#465 subjects which CreditX rejected could have been non defaulters based on the model and would have given additional revenue.

reject_woe_df$performance<-ifelse(reject_woe_df$Score<cutoff_score,0,1)
ggplot(reject_woe_df, aes(x = Score,fill=as.factor(reject_woe_df$performance)))+  geom_bar()+ 
  scale_fill_manual("legend", values = c("0" ="#FF9999" , "1" = "#99CC66")) +
  geom_vline(aes(xintercept = cutoff_score),colour = "red")+labs(x="Score",y="Count",title="Score Distribution for all applicants")+
    annotate("text", x=370,y=1, colour = "navy",hjust=0.3, vjust=-10, size=7, label=paste("Rejections based on score card cut off :" ,
        scorecard_based_rejections,"applicants /",perc_of_rejects_basedon_cutoff,"% of total rejected population"))

#Overall the selected model is able to isolate 72% of defaults in 27% of low score applications thus reducing credit loss..
#At the same time, model may save loss of revenue with use of scorecard in applications which otherwise would have been rejected without the model.

##########################################################################
#Financial Analysis/Benefits
##########################################################################
#For financial analysis, without knowing the credit exposure to the prospects, we will hypothetically assume that 
#the outstanding amounts in the given data is the amount CreditX expects to provide as credit and assess model benefits

merged_df$Score<- scorecard_df$Score
rejected_applications$Score<-reject_woe_df$Score

approved_by_model<- merged_df[which(merged_df$Score>=cutoff_score),]
nrow(approved_by_model)
#50656 subjects are approved by model.CreditX will get re-validation on their approvals and can put the model for auto approvals.

rejected_by_model<-merged_df[which(merged_df$Score<cutoff_score),]
nrow(rejected_by_model)
#18845 subjects will be rejected by model.CreditX may want to reassess their creditworthiness before approving. 

rejects_approved_by_model<-rejected_applications[which(rejected_applications$Score>=cutoff_score),]
rejects_rejected_by_model<-rejected_applications[which(rejected_applications$Score<cutoff_score),]


#install.packages("english")
library(english)

#Topline Impact--------------------

#Subjects that CreditX approved & Model approved as well-Model aiding in approvals
model_approved_credit<-sum(approved_by_model[which(approved_by_model$performance==0),"outst_bal"])
model_approved_credit
#62082353475
as.english(model_approved_credit)
#sixty two billion eighty two million three hundred fifty three thousand four hundred seventy five

#Model based approvals of rejects - subjects which were rejected by CreditX:Amounting to increase in revenue
revenue_on_screening_rejects<-sum(rejects_approved_by_model$outst_bal)
revenue_on_screening_rejects
#505105202
as.english(revenue_on_screening_rejects)
#five hundred five million one hundred five thousand two hundred two


#Bottomline Impact----------------

#Saving on loss based on Model rejection - Actual defaulters which were approved by CreditX
rejection_saving<-sum(rejected_by_model[which(rejected_by_model$performance==1),"outst_bal"])
rejection_saving
#2659279665
as.english(rejection_saving)
#two billion six hundred fifty nine million two hundred seventy nine thousand six hundred sixty five

default_ratio_below_cutoff<-num_of_defaults_below_cutoff*100/cutoffrecs
round(default_ratio_below_cutoff,digits = 2)
#Default ratio of subjects below model cutoff is at 11.27% which is very high

default_ratio_above_cutoff<-num_of_defaults_above_cutoff*100/apprrecs
round(default_ratio_above_cutoff,digits = 2)
#Default ratio of subjects above model cutoff is at 1.61% which is way low compared to 4.13% without model.
#Thus this model will be able to bring in significant improvements in reducing defaults.
##############################################End#########################################